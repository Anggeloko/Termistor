/*******************************************************************************
* File Name: Vtermistor.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Vtermistor_H) /* Pins Vtermistor_H */
#define CY_PINS_Vtermistor_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Vtermistor_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Vtermistor__PORT == 15 && ((Vtermistor__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Vtermistor_Write(uint8 value);
void    Vtermistor_SetDriveMode(uint8 mode);
uint8   Vtermistor_ReadDataReg(void);
uint8   Vtermistor_Read(void);
void    Vtermistor_SetInterruptMode(uint16 position, uint16 mode);
uint8   Vtermistor_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Vtermistor_SetDriveMode() function.
     *  @{
     */
        #define Vtermistor_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Vtermistor_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Vtermistor_DM_RES_UP          PIN_DM_RES_UP
        #define Vtermistor_DM_RES_DWN         PIN_DM_RES_DWN
        #define Vtermistor_DM_OD_LO           PIN_DM_OD_LO
        #define Vtermistor_DM_OD_HI           PIN_DM_OD_HI
        #define Vtermistor_DM_STRONG          PIN_DM_STRONG
        #define Vtermistor_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Vtermistor_MASK               Vtermistor__MASK
#define Vtermistor_SHIFT              Vtermistor__SHIFT
#define Vtermistor_WIDTH              1u

/* Interrupt constants */
#if defined(Vtermistor__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Vtermistor_SetInterruptMode() function.
     *  @{
     */
        #define Vtermistor_INTR_NONE      (uint16)(0x0000u)
        #define Vtermistor_INTR_RISING    (uint16)(0x0001u)
        #define Vtermistor_INTR_FALLING   (uint16)(0x0002u)
        #define Vtermistor_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Vtermistor_INTR_MASK      (0x01u) 
#endif /* (Vtermistor__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Vtermistor_PS                     (* (reg8 *) Vtermistor__PS)
/* Data Register */
#define Vtermistor_DR                     (* (reg8 *) Vtermistor__DR)
/* Port Number */
#define Vtermistor_PRT_NUM                (* (reg8 *) Vtermistor__PRT) 
/* Connect to Analog Globals */                                                  
#define Vtermistor_AG                     (* (reg8 *) Vtermistor__AG)                       
/* Analog MUX bux enable */
#define Vtermistor_AMUX                   (* (reg8 *) Vtermistor__AMUX) 
/* Bidirectional Enable */                                                        
#define Vtermistor_BIE                    (* (reg8 *) Vtermistor__BIE)
/* Bit-mask for Aliased Register Access */
#define Vtermistor_BIT_MASK               (* (reg8 *) Vtermistor__BIT_MASK)
/* Bypass Enable */
#define Vtermistor_BYP                    (* (reg8 *) Vtermistor__BYP)
/* Port wide control signals */                                                   
#define Vtermistor_CTL                    (* (reg8 *) Vtermistor__CTL)
/* Drive Modes */
#define Vtermistor_DM0                    (* (reg8 *) Vtermistor__DM0) 
#define Vtermistor_DM1                    (* (reg8 *) Vtermistor__DM1)
#define Vtermistor_DM2                    (* (reg8 *) Vtermistor__DM2) 
/* Input Buffer Disable Override */
#define Vtermistor_INP_DIS                (* (reg8 *) Vtermistor__INP_DIS)
/* LCD Common or Segment Drive */
#define Vtermistor_LCD_COM_SEG            (* (reg8 *) Vtermistor__LCD_COM_SEG)
/* Enable Segment LCD */
#define Vtermistor_LCD_EN                 (* (reg8 *) Vtermistor__LCD_EN)
/* Slew Rate Control */
#define Vtermistor_SLW                    (* (reg8 *) Vtermistor__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Vtermistor_PRTDSI__CAPS_SEL       (* (reg8 *) Vtermistor__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Vtermistor_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Vtermistor__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Vtermistor_PRTDSI__OE_SEL0        (* (reg8 *) Vtermistor__PRTDSI__OE_SEL0) 
#define Vtermistor_PRTDSI__OE_SEL1        (* (reg8 *) Vtermistor__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Vtermistor_PRTDSI__OUT_SEL0       (* (reg8 *) Vtermistor__PRTDSI__OUT_SEL0) 
#define Vtermistor_PRTDSI__OUT_SEL1       (* (reg8 *) Vtermistor__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Vtermistor_PRTDSI__SYNC_OUT       (* (reg8 *) Vtermistor__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Vtermistor__SIO_CFG)
    #define Vtermistor_SIO_HYST_EN        (* (reg8 *) Vtermistor__SIO_HYST_EN)
    #define Vtermistor_SIO_REG_HIFREQ     (* (reg8 *) Vtermistor__SIO_REG_HIFREQ)
    #define Vtermistor_SIO_CFG            (* (reg8 *) Vtermistor__SIO_CFG)
    #define Vtermistor_SIO_DIFF           (* (reg8 *) Vtermistor__SIO_DIFF)
#endif /* (Vtermistor__SIO_CFG) */

/* Interrupt Registers */
#if defined(Vtermistor__INTSTAT)
    #define Vtermistor_INTSTAT            (* (reg8 *) Vtermistor__INTSTAT)
    #define Vtermistor_SNAP               (* (reg8 *) Vtermistor__SNAP)
    
	#define Vtermistor_0_INTTYPE_REG 		(* (reg8 *) Vtermistor__0__INTTYPE)
#endif /* (Vtermistor__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Vtermistor_H */


/* [] END OF FILE */
