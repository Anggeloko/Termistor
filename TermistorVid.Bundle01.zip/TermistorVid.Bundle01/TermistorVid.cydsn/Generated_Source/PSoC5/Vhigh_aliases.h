/*******************************************************************************
* File Name: Vhigh.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Vhigh_ALIASES_H) /* Pins Vhigh_ALIASES_H */
#define CY_PINS_Vhigh_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Vhigh_0			(Vhigh__0__PC)
#define Vhigh_0_INTR	((uint16)((uint16)0x0001u << Vhigh__0__SHIFT))

#define Vhigh_INTR_ALL	 ((uint16)(Vhigh_0_INTR))

#endif /* End Pins Vhigh_ALIASES_H */


/* [] END OF FILE */
