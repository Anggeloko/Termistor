/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>

int main()
{
    CyGlobalIntEnable;
    
    int32 Vtherm,Vref;
    int32 TermResis,TermTemp;
    float TermirstorResis,TermistorTemp;
    char str[12];
    
    
    ADC_Start();
    LCD_Start();
    AMux_Start();
    Opamp_1_Start();
    
    LCD_Position(0,0);
    LCD_PrintString("Ejemplo Termistor");
    LCD_Position(1,0);
    LCD_PrintString("NTC KY-013");
    

    for(;;)
    {
        AMux_FastSelect(0);
        ADC_StartConvert();
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        Vtherm = ADC_GetResult32();
        ADC_StopConvert();
        
        AMux_FastSelect(1);
        ADC_StartConvert();
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        Vref = ADC_GetResult32();
        ADC_StopConvert();
        
        
        TermResis = Thermistor_GetResistance(Vref,Vtherm);
        TermTemp = Thermistor_GetTemperature(TermResis);
        
        TermirstorResis = TermResis/1000.000;
        TermistorTemp = TermTemp / 100.00;
        
        LCD_Position(2,0);
        LCD_PrintString("Resistencia: ");
        sprintf(str,"%.3fK ",TermirstorResis);
        LCD_PrintString(str);
        
        LCD_Position(3,0);
        LCD_PrintString("Temp: ");
        sprintf(str,"%.2f.C ",TermistorTemp);
        LCD_PrintString(str);
        
        CyDelay(300);
        
        
    }
}

/* [] END OF FILE */
